// Mohammad moein Hazari
// 109830182
// mhazari


#ifndef SDDS_ELEMENT_H
#define SDDS_ELEMENT_H

#include <iomanip>
#include <string>
#include <fstream>

extern const int FWC;
extern const int FWD;
extern const int FWP;

namespace sdds {

	struct Description {
		unsigned code;
		std::string desc;
		bool load(std::ifstream& f) {
			f >> code >> desc;
			return f.good();
		}

		void display(std::ostream& os) const {
			os << std::setw(FWC) << code
				<< std::setw(FWD) << desc
				<< std::endl;
		}
	};

	struct Price {
		unsigned code;
		double price;
		bool load(std::ifstream& f) {
			f >> code >> price;
			return f.good();
		}

		void display(std::ostream& os) const {
			os << std::setw(FWC) << code << std::setw(FWP)
				<< price << std::endl;
		}
	};

	struct Product {
		std::string p_desc{};
		double p_price{};
		int p_id{};
		static size_t id_finder;
		// this variable is used to print trace messages from
		//     constructors/destructor
		static bool Trace;

		Product() {
			p_id = ++Product::id_finder;
			if (Product::Trace)
				std::cout << "    DC [" << p_id << "]" << std::endl;
		}

		Product(const std::string& str, double p) {
			this->p_desc = str;
			this->p_price = p;
			p_id = ++Product::id_finder;
			if (Product::Trace)
				std::cout << "     C [" << p_id << "]" << std::endl;
		}

		Product(const Product& other) {
			this->p_desc = other.p_desc;
			this->p_price = other.p_price;
			p_id = ++Product::id_finder;
			if (Product::Trace)
				std::cout << "    CC [" << p_id
				<< "] from [" << other.p_id << "]"
				<< std::endl;
		}

		~Product() {
			if (Product::Trace)
				std::cout << "    ~D [" << p_id << "]" << std::endl;
		}

		// TODO: add a function here to validate the price

		struct ValidateException : public std::exception {
			std::string message;
			ValidateException(std::string message) : message(message) {}
			~ValidateException() throw() {}
			const char *what() const throw() { return message.c_str(); }
		};

		inline void validate() {
			std::string message = "*** Negative prices are invalid ***";
			if (this->p_price < 0) throw message;
		}

		void display(std::ostream& os) const {
			os << std::setw(FWD) << p_desc
				<< std::setw(FWP) << p_price
				<< std::endl;
		}
	};
}
#endif