// Workshop 5 
// Name: Mohammad moein Hazari
// Seneca Student ID: 109830182
// Seneca email:mhazari@myseneca.ca

#include "SpellChecker.h"

namespace sdds {

	SpellChecker::SpellChecker() {
		MbadWords[0] = '\0';
		MgoodWords[0] = '\0';
	}
	SpellChecker::SpellChecker(const char* filename) {
		std::string temp;
		std::ifstream f(filename);
		if (!f)
		{
			throw "Bad file name!";
		}
		else {
			do
			{
				std::getline(f, temp);
				if (f)
				{
					size_t i = 0u;
					size_t posS = 0u;
					size_t posE = temp.find(' ');
					MbadWords[count] = temp.substr(posS, posE - posS);
					temp.erase(posS, posE - posS);
					for (i = 0; i < temp.length() && temp[i] == ' '; i++);
					posS = i;
					MgoodWords[count] = temp.substr(posS);
					count++;
				}
			} while (f);
		}
		f.close();
	}

	
	
	void SpellChecker::operator()(std::string& text) const {
		size_t position = 0u;

		
		for (int i = 0; i < count; i++) {
			position = text.find(MbadWords[i]);
			if (position != text.npos) {
				while (position != text.npos) {
					text.replace(position, MbadWords[i].length(), MgoodWords[i]);
					position = text.find(MbadWords[i]);
				}
			}
		}
	}

}