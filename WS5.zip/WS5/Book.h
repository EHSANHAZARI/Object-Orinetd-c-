// Workshop 5 
// Name: Mohammad moein Hazari
// Seneca Student ID: 109830182
// Seneca email:mhazari@myseneca.ca


#define _CRT_SECURE_NO_WARNINGS
#ifndef SDDS_BOOK_H
#define SDDS_BOOK_H
#include <iostream>
#include <iomanip>
#include <string>

namespace sdds {
	class Book {
	private:
		std::string	Mauthor;
		std::string Mtitle;
		std::string mcountry;
		std::string  mdescription;
		double m_price;
		size_t Myear;

		void trim(std::string& str) const; 

	public:
		Book();
		Book(const std::string strBook);

		const std::string& title() const { return Mtitle; }
		const std::string& country() const { return mcountry; }
		const size_t& year() const { return Myear; }
		double& price() { return m_price; } 

		template<typename T>
		void fixSpelling(T spellChecker) {
			spellChecker( mdescription);
		}

		friend std::ostream& operator<<(std::ostream& os, const Book& b);
	};
}

#endif // !SDDS_BOOK_H