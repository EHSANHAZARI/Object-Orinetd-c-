// Workshop 5 
// Name: Mohammad moein Hazari
// Seneca Student ID: 109830182
// Seneca email:mhazari@myseneca.ca

#define _CRT_SECURE_NO_WARNINGS
#include "Book.h"

namespace sdds {

	
	
	void Book::trim(std::string& str) const {
		size_t i = 0u;
		
		for (i = 0u; i < str.length() && str[i] == ' '; ++i);
		
		str = str.substr(i);
		for (i = str.length(); i > 0 && str[i - 1] == ' '; --i);
		str = str.substr(0, i);
	}

	
	Book::Book() {
		Mauthor = "";
		Mtitle = "";
		mcountry = "";
		 mdescription = "";
		m_price = 0.0;
		Myear = 0u;
	}

	
	
	Book::Book(const std::string strBook) {
		size_t posS = 0;
		size_t posE = strBook.find(',');
		this->trim(Mauthor = strBook.substr(posS, posE));

		posS = posE + 1;
		posE = strBook.find(',', posS);
		this->trim(Mtitle = strBook.substr(posS, posE - posS));

		posS = posE + 1;
		posE = strBook.find(',', posS);
		this->trim(mcountry = strBook.substr(posS, posE - posS));

		posS = posE + 1;
		posE = strBook.find(',', posS);
		this->m_price = std::stod(strBook.substr(posS, posE - posS));

		posS = posE + 1;
		posE = strBook.find(',', posS);
		this->Myear = std::stoi(strBook.substr(posS, posE - posS));

		posS = posE + 1;
		this->trim( mdescription = strBook.substr(posS));
	}

	
	std::ostream& operator<<(std::ostream& os, const Book& b) {
		os << std::setw(20) << b.Mauthor << " | " << std::setw(22) << b.Mtitle << " | " << std::setw(5) << b.mcountry
			<< " | " << std::setw(4) << b.Myear << " | " << std::fixed << std::setw(6) << std::setprecision(2) << b.m_price << " | " << b. mdescription << std::endl;
		return os;
	}


}