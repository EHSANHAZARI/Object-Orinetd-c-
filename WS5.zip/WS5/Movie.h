// Workshop 5 
// Name: Mohammad moein Hazari
// Seneca Student ID: 109830182
// Seneca email:mhazari@myseneca.ca

#define _CRT_SECURE_NO_WARNINGS
#ifndef SDDS_MOVIE_H
#define SDDS_MOVIE_H

#include <iostream>
#include <iomanip>
#include <string>

namespace sdds
{
	class Movie
	{
	private:
		std::string Mtitle = "";
		std::string  mdescription = "";
		size_t Myear = 0u;

		void trim(std::string& str) const; 
	public:
		Movie() {};
		Movie(const std::string& strMovie);
		const std::string& title() const { return Mtitle; };

	
		
		template<typename T>
		void fixSpelling(T spellChecker) {
			spellChecker(Mtitle);
			spellChecker( mdescription);
		}
		friend std::ostream& operator<<(std::ostream& os, const Movie& m);
	};
}

#endif // !SDDS_MOVIE_H