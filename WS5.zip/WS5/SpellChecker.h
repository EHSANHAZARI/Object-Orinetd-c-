// Workshop 5 
// Name: Mohammad moein Hazari
// Seneca Student ID: 109830182
// Seneca email:mhazari@myseneca.ca

#define _CRT_SECURE_NO_WARNINGS
#ifndef SDDS_SPELLCHECKER_H
#define SDDS_SPELLCHECKER_H

#include <iostream>
#include <string>
#include <fstream>

namespace sdds
{
	class SpellChecker
	{
	private:
		std::string MbadWords[5];
		std::string MgoodWords[5];
		int count = 0;
	public:
		SpellChecker();
		SpellChecker(const char* filename);
		void operator()(std::string& text) const;
	};
}

#endif // !SDDS_SPELLCHECKER_H