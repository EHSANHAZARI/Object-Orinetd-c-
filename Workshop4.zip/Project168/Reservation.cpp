// Workshop 4 - Containers
// Reservation.cpp
// Name: Mohammad moein Hazari
// Seneca Student ID: 109830182
// Seneca email:mhazari@myseneca.ca
// Date of completion: Oct 11, 2019
#include <iostream>
#include <cstring>
#include <iomanip>
#include <algorithm>
#include "Reservation.h"

using namespace std;

namespace sdds
{
	Reservation::Reservation()
	{
		ResId = "";
		Rname = "";
		Remail = "";
		num_p = 0;
		Rday = 0;
		Rhour = 0;
	}

	Reservation::Reservation(const string& m_res)
	{
		// reservation id 
		int n_id = m_res.find(':');
		ResId = m_res.substr(0, n_id);
		ResId.erase(remove(ResId.begin(), ResId.end(), ' '), ResId.end());

		// name 
		int n_name = m_res.find(',');
		Rname = m_res.substr(n_id + 1, n_name - n_id - 1);
		Rname.erase(remove(Rname.begin(), Rname.end(), ' '), Rname.end());

		// email
		int n_email = m_res.find(',', n_name + 1);
		Remail.insert(0, "<");
		Remail.append(m_res.substr(n_name + 1, n_email - n_name - 1));
		Remail.erase(remove(Remail.begin(), Remail.end(), ' '), Remail.end());
		Remail.append(">");

		//size of people
		int n_people = m_res.find(',', n_email + 1);
		num_p = stoi(m_res.substr(n_email + 1, n_people - n_email - 1));


		// reservation day
		int n_day = m_res.find(',', n_people + 1);
		Rday = stoi(m_res.substr(n_people + 1, n_day - n_people - 1));

		// reservation hour
		int n_hour = m_res.length();
		Rhour = stoi(m_res.substr(n_day + 1, n_hour - n_day - 1));


	}

	std::ostream& operator<<(std::ostream& os, const Reservation& r_temp)
	{

		os << "Reservation " << r_temp.ResId << ": " << setw(10) << right << r_temp.Rname << "  ";
		os << left << setw(20) << r_temp.Remail << "    ";
		if (r_temp.Rhour >= 6 && r_temp.Rhour <= 9)
		{
			os << "Breakfast on day " << r_temp.Rday;

		}
		else if (r_temp.Rhour >= 11 && r_temp.Rhour <= 15)
		{
			os << "Lunch on day " << r_temp.Rday;
		}
		else if (r_temp.Rhour >= 17 && r_temp.Rhour <= 21)
		{
			os << "Dinner on day " << r_temp.Rday;
		}
		else
		{
			os << "Drinks on day " << r_temp.Rday;
		}

		os << " @ " << r_temp.Rhour << ":00 for " << r_temp.num_p << " people." << endl;
		return os;
	}



}