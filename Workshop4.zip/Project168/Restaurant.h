// Workshop 4 - Containers
// Reservation.cpp
// Name: Mohammad moein Hazari
// Seneca Student ID: 109830182
// Seneca email:mhazari@myseneca.ca
// Date of completion: Oct 11, 2019

#pragma once
#ifndef SDDS_RESTAURANT_H
#define SDDS_RESTAURANT_H
#include "Reservation.h"
#include <string>
#include <iostream>
#include <iomanip>

namespace sdds
{
	class Restaurant
	{
	private:
		Reservation* res_d;
		size_t num;
	public:
		Restaurant();
		~Restaurant();
		Restaurant(Reservation* reservations[], size_t cnt = 0);
		Restaurant(const Restaurant& temp);
		Restaurant(Restaurant&& temp);
		size_t size() const;
		Restaurant& operator=(const Restaurant& temp);
		Restaurant& operator=(Restaurant&& temp);
		friend std::ostream& operator<<(std::ostream& os, const Restaurant& r_temp);
	};
}

#endif