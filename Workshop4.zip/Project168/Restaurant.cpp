// Workshop 4 - Containers
// Reservation.cpp
// Name: Mohammad moein Hazari
// Seneca Student ID: 109830182
// Seneca email:mhazari@myseneca.ca
// Date of completion: Oct 11, 2019
#include <string>
#include <iostream>
#include <iomanip>
#include <utility>
#include "Reservation.h"
#include "Restaurant.h"

using namespace std;
namespace sdds
{
	Restaurant::Restaurant()
	{
		res_d = nullptr;
		num = 0;
	}

	Restaurant::~Restaurant()
	{
		delete[] res_d;
	}

	Restaurant::Restaurant(Reservation* reservations[], size_t cnt)
	{
		if (cnt > 0 && reservations != nullptr)
		{
			res_d = new Reservation[cnt];
			num = 0;
			for (size_t i = 0u; i < cnt; i++)
			{
				res_d[num] = *reservations[i];
				num++;
			}
		}
		else
		{
			*this = Restaurant();
		}
	}

	Restaurant::Restaurant(const Restaurant& temp)
	{
		*this = temp;
	}

	Restaurant::Restaurant(Restaurant&& temp)
	{
		*this = std::move(temp);
	}

	size_t Restaurant::size() const
	{
		return num;
	}

	Restaurant& Restaurant::operator=(const Restaurant& temp)
	{
		if (this != &temp)
		{

			res_d = new Reservation[temp.size()];
			num = temp.num;
			for (size_t i = 0; i < num; i++)
			{
				res_d[i] = temp.res_d[i];
			}

		}
		return *this;
	}

	Restaurant& Restaurant::operator=(Restaurant&& temp)
	{
		if (this != &temp)
		{

			num = temp.num;
			res_d = temp.res_d;


			temp.num = 0;
			temp.res_d = nullptr;
		}

		return *this;
	}

	std::ostream& operator<<(std::ostream& os, const Restaurant& r_temp)
	{
		os << "--------------------------" << endl;
		os << "Fancy Restaurant" << endl;
		os << "--------------------------" << endl;

		if (r_temp.size() == 0)
		{
			os << "The object is empty!" << endl;
		}
		else
		{
			for (size_t i = 0; i < r_temp.num; i++)
			{
				os << r_temp.res_d[i];
			}
		}
		os << "--------------------------" << endl;
		return os;
	}
}