// Workshop 4 - Containers
// Reservation.cpp
// Name: Mohammad moein Hazari
// Seneca Student ID: 109830182
// Seneca email:mhazari@myseneca.ca
// Date of completion: Oct 11, 2019
#pragma once
#ifndef SDDS_CONFIRMATIONSENDER_H
#define SDDS_CONFIRMATIONSENDER_H
#include <iostream>
#include <cstring>
#include <iomanip>
#include <algorithm>
#include "Reservation.h"
#include "Restaurant.h"

namespace sdds
{
	class ConfirmationSender
	{
	private:
		const Reservation** confirmS;
		size_t c_num;

	public:
		ConfirmationSender();
		ConfirmationSender(const ConfirmationSender& res);
		ConfirmationSender(ConfirmationSender&& res);
		ConfirmationSender& operator+=(const Reservation& res);
		ConfirmationSender& operator-=(const Reservation& res);
		~ConfirmationSender();


		friend std::ostream& operator<<(std::ostream& os, const ConfirmationSender& r_temp);
	};
}
#endif // !1