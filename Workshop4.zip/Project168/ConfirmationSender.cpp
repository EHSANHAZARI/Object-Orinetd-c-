// Workshop 4 - Containers
// Reservation.cpp
// Name: Mohammad moein Hazari
// Seneca Student ID: 109830182
// Seneca email:mhazari@myseneca.ca
// Date of completion: Oct 11, 2019

#include <iostream>
#include <cstring>
#include <iomanip>
#include <algorithm>
#include "Reservation.h"
#include "Restaurant.h"
#include "ConfirmationSender.h"

namespace sdds
{
	ConfirmationSender::ConfirmationSender()
	{
		confirmS = nullptr;
		c_num = 0;
	}

	ConfirmationSender::~ConfirmationSender()
	{
		delete[] confirmS;
	}


	ConfirmationSender::ConfirmationSender(const ConfirmationSender& res)
	{
		c_num = res.c_num;
		if (c_num > 0)
		{
			confirmS = const_cast<const Reservation**>(new Reservation*[c_num]);
			for (size_t i = 0; i < c_num; i++) {
				confirmS[i] = res.confirmS[i];
			}
		}
		else
		{
			confirmS = nullptr;
		}
	}

	ConfirmationSender::ConfirmationSender(ConfirmationSender&& res)
	{
		confirmS = res.confirmS;
		c_num = res.c_num;
		res.confirmS = nullptr;
		res.c_num = 0;
	}


	ConfirmationSender& ConfirmationSender::operator+=(const Reservation& res)
	{
		bool not_found = true;

		for (size_t i = 0; i < c_num && not_found; i++) {
			if (confirmS[i] == &res) {
				not_found = false;
			}
		}

		if (not_found) {
			Reservation** tmp = new Reservation*[c_num + 1];

			for (size_t i = 0; i < c_num; i++) {
				tmp[i] = const_cast<Reservation*>(confirmS[i]);
			}

			delete[] confirmS;
			confirmS = const_cast<const Reservation**>(tmp);
			confirmS[c_num++] = &res;
		}
		return *this;
	}

	ConfirmationSender& ConfirmationSender::operator-=(const Reservation& res)
	{
		bool not_found = true;
		size_t i = 0;

		for (; i < c_num && not_found; i++)
		{
			if (confirmS[i] == &res) {
				not_found = false;
			}
		}

		if (!not_found) {
			Reservation** tmp = new Reservation*[c_num--];

			if (i > 0)
			{

				for (size_t j = 0; j < i; j++)
				{
					tmp[j] = const_cast<Reservation*>(confirmS[j]);
				}
			}

			for (size_t j = i; j < c_num; j++)
			{
				tmp[j] = const_cast<Reservation*>(confirmS[j + 1]);
			}
			delete[] confirmS;
			confirmS = const_cast<const Reservation**>(tmp);
		}
		return *this;
	}

	std::ostream& operator<<(std::ostream& os, const ConfirmationSender& c_temp)
	{
		os << "--------------------------" << endl;
		os << "Confirmations to Send" << endl;
		os << "--------------------------" << endl;

		if (c_temp.c_num == 0)
		{
			os << "The object is empty!" << endl;
		}
		else
		{
			for (size_t i = 0; i < c_temp.c_num; i++)
				os << *c_temp.confirmS[i];
		}
		os << "--------------------------" << std::endl;
		return os;
	}
}