// Workshop 4 - Containers
// Reservation.cpp
// Name: Mohammad moein Hazari
// Seneca Student ID: 109830182
// Seneca email:mhazari@myseneca.ca
// Date of completion: Oct 11, 2019
#pragma once
#ifndef  SDDS_RESERVATION_H
#define SDDS_RESERVATION_H
#include <string>
#include <iostream>
#include <iomanip>

using namespace std;
namespace sdds
{
	class Reservation
	{
	private:
		string ResId;
		string Rname;
		string Remail;
		int num_p;
		int Rday;
		int Rhour;

	public:
		Reservation();
		Reservation(const string& m_res);

		friend std::ostream& operator<<(std::ostream& os, const Reservation& r_temp);
	};

}

#endif // ! SDDS_RESERVATION_H