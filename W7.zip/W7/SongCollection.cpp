// Name:              Mohammad moein Hazari
// Seneca Student ID: 109830182
// Seneca email:	  mhazari@myseneca.ca
// Date of completion:2019 Nov 12

#include "SongCollection.h"
#include<iostream>
#include<iomanip>
#include<fstream>
#include<string>
#include<algorithm>
#include<vector>
#include<list>
#include <numeric> 

namespace sdds
{
	std::ostream& operator<<(std::ostream& out, const Song& theSong)
	{
		int second;
		second = theSong.Mlength % 60;
		out << "| " << std::setw(20) << std::left << theSong.Mtitle
			<< " | " << std::setw(15) << std::left << theSong.Martist
			<< " | " << std::setw(20) << std::left << theSong.Malbum
			<< " | " << std::setw(6) << std::right;
		if (theSong.Myear != 0)
			out << theSong.Myear;
		else
			out << "";
		out << " | " << theSong.Mlength / 60 << ":";

		if (second < 10)
		{
			out << "0";
		}
		out << second
			<< " | " << theSong.Mprice << " | ";

		return out;
	}
	std::string& SongCollection::trim(std::string& check)
	{
		while (check.length() > 0 && check[0] == ' ')
			check.erase(0, 1);
		while (check.length() > 0 && check[check.length() - 1] == ' ')
			check.erase(check.length() - 1, 1);

		return check;
	}

	SongCollection::SongCollection(std::string filename)
	{
		std::ifstream file(filename);
		if (!file)
		{
			std::cout << "Can not open the file" << std::endl;
		}
		else
		{
			while (file)
			{
				Song song;
				std::string tmp;
				std::getline(file, tmp);
				if (file)
				{
					trim(song.Mtitle = tmp.substr(0, 25));
					trim(song.Martist = tmp.substr(25, 25));
					trim(song.Malbum = tmp.substr(50, 25));
					try {
						song.Myear = std::stoi(tmp.substr(75, 5));
					}
					catch (...)
					{
						song.Myear = 0;
					}
					song.Mlength = std::stoi(tmp.substr(80, 5));
					song.Mprice = std::stod(tmp.substr(85));

					m_songs.push_back(song);
				}
			}
			file.close();
		}
	}
	void SongCollection::display(std::ostream& out) const
	{
		for_each(m_songs.begin(), m_songs.end(), [&out](const Song& list)
		{
			out << list << std::endl;
		});


		auto sum = std::accumulate(m_songs.begin(), m_songs.end(), 0, [](const size_t& res, const Song& thesong) {
			return res + thesong.Mlength;
		});
		out << std::setw(89) << std::setfill('-') << '\n' << std::setfill(' ');

		std::string str = "Total Listening Time: ";
		str += std::to_string(sum / 3600);
		str += ":";
		str += std::to_string((sum %= 3600) / 60);
		str += ":";
		str += std::to_string(sum % 60);
		out << "| " << std::setw(84) << str << " |" << std::endl;
	}

	void SongCollection::sort(std::string filed)
	{
		if (filed == "title")
			std::sort(m_songs.begin(), m_songs.end(), [](const Song& a, const Song& b) {return a.Mtitle < b.Mtitle; });
		else if (filed == "album")
			std::sort(m_songs.begin(), m_songs.end(), [](const Song& a, const Song& b) {return a.Malbum < b.Malbum; });
		else if (filed == "length")
			std::sort(m_songs.begin(), m_songs.end(), [](const Song& a, const Song& b) {return a.Mlength < b.Mlength; });
	}
	void SongCollection::cleanAlbum()
	{
		for_each(m_songs.begin(), m_songs.end(), [](Song& song) {
			if (song.Malbum == "[None]")
			{
				song.Malbum = "";
			}
		});
	}
	bool SongCollection::inCollection(std::string name) const
	{
		auto res = std::find_if(m_songs.begin(), m_songs.end(), [&name](const Song& song) {return song.Martist == name; });
		return res != m_songs.end();
	}

	std::list<Song> SongCollection::getSongsForArtist(std::string name) const
	{
		auto cnt = std::count_if(m_songs.begin(), m_songs.end(), [&name](const Song& songs) {
			return songs.Martist == name;
		});
		std::list<Song> song(cnt);

		std::copy_if(m_songs.begin(), m_songs.end(), song.begin(), [&name](const Song& song)
		{
			return song.Martist == name;
		});
		return song;
	}


}