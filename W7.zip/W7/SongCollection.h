// Name:              Mohammad moein Hazari
// Seneca Student ID: 109830182
// Seneca email:	  mhazari@myseneca.ca
// Date of completion:2019 Nov 12



#ifndef SONGCOLLECTION_H__
#define SONGCOLLECTION_H__

#include<string>
#include<iostream>
#include<vector>
#include<list>

namespace sdds
{
	struct Song
	{
		std::string Martist;
		std::string Mtitle;
		std::string Malbum;
		double Mprice;
		int Myear;
		size_t Mlength;
	};

	std::ostream& operator<<(std::ostream& out, const Song& theSong);

	class SongCollection
	{
		std::vector<sdds::Song> m_songs;
	protected:
		std::string& trim(std::string& check);
	public:
		SongCollection(std::string);
		void display(std::ostream& out) const;
		void sort(std::string filed);
		void cleanAlbum();
		bool inCollection(std::string name) const;
		std::list<Song> getSongsForArtist(std::string name) const;

	};

}

#endif