// Name: Mohammad moein Hazari
// Seneca Student 109830182
// Seneca email: mhazari@myseneca.ca
// Date of completion: Oct 1, 2019

#ifndef SDDS_LIST_H
#define SDDS_LIST_H

namespace sdds
{
	template <typename T, size_t N>
	class List
	{
		size_t Elements = 0;
		T list[N];
	public:
		size_t size()const
		{
			return Elements;
		}

		const T& operator[](size_t i)const
		{
			const T& t = list[i];
			return t;
		}

		void operator += (const T& tt)
		{
			if (Elements < N)
			{
				list[Elements] = tt;
				Elements++;
			}
		}
	};

	template<typename L, typename V, typename T, size_t N>
	class LVList : public List<T, N>
	{
	public:
		V accumulate(const L& label) const
		{
			V totSum = SummableLVPair <L, V>::getInitialValue();
			for (size_t i = 0; i < ((List<T, N>&) * this).size(); i++)
			{
				if (label == ((List<T, N>&) * this)[i].key())
				{
					totSum = ((List<T, N>&) * this)[i].sum(label, totSum);
				}
			}
			return totSum;
		}
	};
}
#endif