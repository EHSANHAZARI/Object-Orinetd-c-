// Name: Mohammad moein Hazari
// Seneca Student 109830182
// Seneca email: mhazari@myseneca.ca
// Date of completion: Oct 1, 2019

#ifndef SDDS_LVPAIR_H
#define SDDS_LVPAIR_H

namespace sdds
{
	template<typename L, typename V>
	class LVPair
	{
		L labelA;
		V valueA;
	public:
		LVPair() : labelA{}, valueA{}
		{}

		LVPair(const L& aa, const V& bb) 
		{
			labelA = aa;
			valueA = bb;
		}

		const L& key() const
		{
			return labelA;
		}

		const V& value() const
		{a
			return valueA;
		}

		virtual void display(std::ostream& os)const 
		{
			os << key() << " : " << value() << std::endl;
		}
	};

	template <typename L, typename V>
	class SummableLVPair : public LVPair<L, V>
	{
		static V summationValue;
		static size_t minFieldWidth; 
	public:
		static const V& getInitialValue()
		{
			return summationValue;
		}

		SummableLVPair()
		{}

		SummableLVPair(const L& lbl, const V& val) : LVPair<L, V>(lbl, val)
		{
			if (minFieldWidth < lbl.size())
			{
				minFieldWidth = lbl.size();
			}
		}

		V sum(const L& lbl, const V& val) const
		{
			return val + LVPair<L, V>::value();
		}

		void display(std::ostream& os) const
		{
			os.setf(std::ios::left);
			os.width(minFieldWidth);
			os << LVPair<L, V>::key() << " : " << LVPair<L, V>::value() << std::endl;
			os.unsetf(std::ios::right);
		}
	};

	template <typename L, typename V>
	size_t SummableLVPair<L, V>::minFieldWidth = 0u;

	template <>
	std::string SummableLVPair<std::string, std::string>::summationValue = "";

	template <>
	int SummableLVPair<std::string, int>::summationValue = 0;

	template<typename L, typename V>
	std::ostream& operator<<(std::ostream& os, const sdds::LVPair<L, V>& pair)
	{
		pair.display(os);
		return os;
	}


	template <>
	SummableLVPair <std::string, int>::SummableLVPair(const std::string& label, const int& value) : LVPair<std::string, int>(label, value)
	{
		if (minFieldWidth < label.size())
		{
			minFieldWidth = label.size();
		}
	}

	template<>
	std::string SummableLVPair<std::string, std::string>::sum(const std::string& label, const std::string& sum) const
	{
		if (sum == "")
		{
			return LVPair<std::string, std::string>::value() + sum;
		}
		else
		{
			return (sum + ", " + LVPair<std::string, std::string>::value());
		}
	}
}
#endif