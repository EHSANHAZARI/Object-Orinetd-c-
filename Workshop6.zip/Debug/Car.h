#define _CRT_SECURE_NO_WARNINGS

#ifndef SDDS_CAR_H
#define SDDS_CAR_H

#include <iomanip>
#include <sstream>
#include "Vehicle.h"

namespace sdds
{
	class Car : public Vehicle
	{
	private:
		std::string m_maker = "";
		std::string m_condition = "";
		size_t m_topSpeed = 0u;
	public:
		void trim(std::string& str) const;
		Car(std::istream& is);
		std::string condition() const;
		double topSpeed() const;
		void display(std::ostream& os) const;
	};
}
#endif // !SDDS_CAR_H
