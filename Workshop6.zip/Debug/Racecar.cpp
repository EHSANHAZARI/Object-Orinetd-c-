#include "Racecar.h"

namespace sdds
{
	Racecar::Racecar(std::istream& is) : Car(is) {
		size_t i = 0;
		std::string token;
		std::getline(is, token);

		for (i = 0; i < token.size() && token[i] == ' '; i++);
		token = token.substr(i);
		for (i = token.size(); i > 0 && token[i - 1] == ' '; i--);
		token = token.substr(0, i);

		Mbooster = std::stod(token);
	}
	void Racecar::display(std::ostream& out) const {
		Car::display(out);
		out << "*";
	}
	double Racecar::topSpeed() const {
		return Car::topSpeed() * (1 + Mbooster);
	}
}