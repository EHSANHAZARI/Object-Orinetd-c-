#ifndef SDDS_RACECAR_H
#define SDDS_RACECAR_H

#include "Car.h"

namespace sdds
{
	class Racecar : public Car
	{
	private:
		double Mbooster = 0.0;
	public:
		Racecar(std::istream& is);
		void display(std::ostream& out) const;
		double topSpeed() const;
	};
}

#endif // !SDDS_RACECAR_H
